The simulation parameters must be written in the config.in file, in the root directory. 
You can specify the platform of your preffered gpu, the widh and height in pixels of the plate,
its initial temperature, the air's temperature and the source temperature.

platform:Intel
width:640
height:480
initial_temp:30.0
air_temp:40.0
point_temp:5500.0

The heat source can be moved using the mouse. 
Also some initial parameters, such as the point temperature and 
the air temperature, can be changed during the simulation. 
To proove that this simulation runs better using a GPU, I added 
the possibility to balance the load of computation between the GPU and the CPU. 
This can be done using the slider labeled "f" in the simulation. 
When f is equal to 100, the simulation is ran only on the GPU, otherwise the CPU 
will use 4 threads to make some calculations aswell.